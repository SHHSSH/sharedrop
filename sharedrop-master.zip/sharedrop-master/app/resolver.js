import Resolver from 'ember-resolver';

export default Resolver;
