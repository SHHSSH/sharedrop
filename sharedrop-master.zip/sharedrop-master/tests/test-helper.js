import { setResolver } from 'ember-qunit';
import resolver from './helpers/resolver';

setResolver(resolver);
