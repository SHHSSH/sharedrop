'use strict';

const browsers = [
  'last 2 Chrome versions',
  'last 2 Firefox versions',
  'last 1 Safari versions',
  'last 1 Edge versions',
];

module.exports = {
  browsers,
};
